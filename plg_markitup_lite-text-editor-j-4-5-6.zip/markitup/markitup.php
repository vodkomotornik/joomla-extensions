<?php
defined('_JEXEC') or die;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

class PlgSystemMarkitup extends CMSPlugin
{
    protected $app;
    protected $autoloadLanguage = true;

    public function __construct($subject, $config = [])
    {
        parent::__construct($subject, $config);
        $this->app = Factory::getApplication();
    }

    public function onBeforeCompileHead()
    {
        $doc = $this->app->getDocument();
        if (!($doc instanceof \Joomla\CMS\Document\HtmlDocument)) {
            return;
        }

        $selectors = $this->params->get('selectors', '#jform_description');
        $triggers  = $this->params->get('triggers', '');
        $debug     = $this->params->get('debug', 0);

        $selectorArray = array_map('trim', explode(',', $selectors));
        $triggerArray  = array_map('trim', explode(',', $triggers));

        $uri         = Uri::getInstance();
        $currentUrl  = $uri->toString();
        $currentPath = $uri->getPath();
        $queryString = $uri->getQuery();

        $shouldLoad = false;
        foreach ($triggerArray as $trigger) {
            if (empty($trigger)) continue;
            if (strpos($currentUrl, $trigger) !== false ||
                strpos($currentPath, $trigger) !== false ||
                strpos($queryString, $trigger) !== false) {
                $shouldLoad = true;
                if ($debug) {
                    $doc->addScriptDeclaration("console.log('MarkItUp New: Trigger matched: " . addslashes($trigger) . "');");
                }
                break;
            }
        }

        if (!$shouldLoad) {
            return;
        }

        // Инлайн CSS
        $css = "
.markitup-new-wrap { border: 1px solid #ccc; border-radius: 3px; font-family: Arial, sans-serif; max-width: 100%; background: #fff; }
.markitup-new-toolbar { background: #f5f5f5; border-bottom: 1px solid #ccc; padding: 5px; display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
.markitup-new-toolbar button { padding: 2px 6px 2px; border: 1px solid #bbb; background: #fff; border-radius: 3px; font-size: 12px; font-family: monospace, system-ui;font-weight: 600;min-width: 28px; color: #333; cursor: pointer; }
.markitup-new-toolbar button:hover { background: #e8e8e8; }
.markitup-new-toolbar .markitup-new-sep { width: 1px; height: 20px; background: #bbb; margin: 0 3px; }
.markitup-new-textarea {
    width: 100%;
    min-height: 150px !important;
    border: none;
    outline: none;
    padding: 8px;
    font-family: Consolas, Monaco, monospace;
    font-size: 14px;
    box-sizing: border-box;
    resize: vertical;
    display: block;
}
";
        $doc->addStyleDeclaration($css);

        // Инлайн JS
        $selectorsJson = json_encode($selectorArray);
        $debugMode     = $debug ? 'true' : 'false';

        $js = "
		(function() {
			const selectors = {$selectorsJson};
			const debug = {$debugMode};

		const BUTTONS = [
			{ label: 'p',  open: '<p>',  close: '</p>', title: 'Абзац' },
			{ label: 'b',  open: '<b>',  close: '</b>', title: 'Жирный' },
			{ label: 'strong', open: '<strong>', close: '</strong>', title: 'Важный текст' },
			{ label: 'i',  open: '<i>',  close: '</i>', title: 'Курсив' },
			{ label: 'ul', open: '<ul>', close: '</ul>', list: true, title: 'Маркированный список' },
			{ label: 'ol', open: '<ol>', close: '</ol>', list: true, title: 'Нумерованный список' },
			{ label: 'li', open: '<li>', close: '</li>', title: 'Элемент списка' },
			{ sep: true },
			{ label: '–', open: '&#8211;', close: '', title: 'Тире' },
			{ label: 'a',  open: '<a href=\"', close: '\"></a>', title: 'Ссылка' },
			{ sep: true },
			{ label: 'h3', open: '<h3>', close: '</h3>', title: 'Заголовок H3' },
			{ label: 's',  open: '<s>',  close: '</s>', title: 'Зачёркнутый' },
			{ label: 'code', open: '<pre><code>', close: '</code></pre>', title: 'Код' },
			{ label: 'br', open: '<br>', close: '', title: 'Перенос строки' },
			{ label: 'hr', open: '<hr>', close: '', title: 'Горизонтальная линия' },
			{ label: '\\\\', open: '&#92;', close: '', title: 'Обратный слеш' }
		];

    function wrapSelection(textarea, open, close) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;
        const selected = text.substring(start, end);

        textarea.value = text.substring(0, start) + open + selected + close + text.substring(end);
        textarea.focus();

        if (selected.length) {
            textarea.setSelectionRange(start, start + open.length + selected.length + close.length);
        } else {
            textarea.setSelectionRange(start + open.length, start + open.length);
        }
    }

    function wrapList(textarea, open, close) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;
        const selected = text.substring(start, end);

        const lines = selected.split('\\n').filter(line => line.trim() !== '');
        const listItems = lines.map(line => ' <li>' + line + '</li>').join('\\n');

        const before = text.substring(0, start);
        const after  = text.substring(end);

        textarea.value = before + open + '\\n' + listItems + '\\n' + close + after;
        textarea.focus();
        textarea.setSelectionRange(start + open.length + 1, start + open.length + 1 + listItems.length);
    }

    function initEditor(textarea) {
        if (textarea.dataset.markitupNewInit === '1') return;
        textarea.dataset.markitupNewInit = '1';

        textarea.rows = 8;
        textarea.style.height = '';

        const wrap = document.createElement('div');
        wrap.className = 'markitup-new-wrap';

        const toolbar = document.createElement('div');
        toolbar.className = 'markitup-new-toolbar';

        BUTTONS.forEach(b => {
            if (b.sep) {
                const s = document.createElement('span');
                s.className = 'markitup-new-sep';
                toolbar.appendChild(s);
                return;
            }
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.textContent = b.label;
			if (b.title) btn.title = b.title;
            btn.addEventListener('mousedown', e => e.preventDefault());
            btn.addEventListener('click', () => {
                if (b.list) {
                    wrapList(textarea, b.open, b.close);
                } else {
                    wrapSelection(textarea, b.open, b.close);
                }
            });
            toolbar.appendChild(btn);
        });

        textarea.classList.add('markitup-new-textarea');
        textarea.parentNode.insertBefore(wrap, textarea);
        wrap.appendChild(toolbar);
        wrap.appendChild(textarea);

        if (debug) console.log('MarkItUp New initialized on:', textarea.id || textarea.name);
    }

    function runInit() {
        selectors.forEach(sel => {
            try {
                document.querySelectorAll(sel).forEach(initEditor);
            } catch(e) {
                if (debug) console.error('MarkItUp New selector error:', sel, e);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', runInit);
    } else {
        runInit();
    }
})();
";
        $doc->addScriptDeclaration($js);
    }
}