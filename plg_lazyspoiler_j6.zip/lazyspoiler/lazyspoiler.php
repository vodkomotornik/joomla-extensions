<?php
/**
* @package     Joomla.Plugin
* @subpackage  Content.LazySpoiler
* @version     1.2.7
* @license     GNU General Public License version 2 or later
* https://vodkomotornik.ru/runduk/download/12-poleznoe/92-lazyspoiler-plugin-joomla.html
*/
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri; // <-- ВАЖНО: Добавлено для совместимости с Joomla 6

class PlgContentLazySpoiler extends CMSPlugin
{
    protected $autoloadLanguage = false;
    private static $assetsAdded = false;

    public function onContentPrepare($context, &$article, &$params, $limitstart = 0)
    {
        if (is_object($article) && isset($article->text)) {
            $article->text = $this->processSpoilers($article->text);
        } elseif (is_string($article)) {
            $article = $this->processSpoilers($article);
        }
        return true;
    }

    private function processSpoilers($text)
    {

        if (strpos($text, '{spoiler') === false && strpos($text, '{details') === false) {
            return $text;
        }

        // ==========================================
        // 1. Обработка тега {details}
        // ==========================================
        if (strpos($text, '{details') !== false) {
            $patternDetails = '/\{details(.*?)\}(.*?)\{\/details\}/is';
            $text = preg_replace_callback($patternDetails, function($matches) {
                $attrs = $matches[1];
                $content = $matches[2];

                // 1. Извлекаем title
                $title = $this->params->get('default_title', 'Спойлер');
                if (preg_match('/title\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s}]+))/i', $attrs, $m)) {
                    $title = !empty($m[1]) ? $m[1] : (!empty($m[2]) ? $m[2] : $m[3]);
                }

                // 2. Извлекаем class
                $customClass = '';
                if (preg_match('/class\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $attrs, $m)) {
                    $customClass = ' ' . trim(!empty($m[1]) ? $m[1] : $m[2]);
                }

                // 3. Проверяем наличие атрибута open
                $isOpen = (bool) preg_match('/\bopen\b/i', $attrs);
                $openAttr = $isOpen ? ' open' : '';

                // 4. Применяем Lazy Load к картинкам внутри
                if ($this->params->get('lazy_load', 1)) {
                    $content = $this->makeImagesLazy($content);
                }

                // 5. Собираем HTML
				$classAttr = !empty($customClass) ? ' class="' . $customClass . '"' : '';
				$html = '<details' . $classAttr . $openAttr . '>';
				$html .= '<summary>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</summary>';
				$html .= '<div class="spoiler-content">';
				$html .= $content;
				$html .= '</div>';
				$html .= '</details>';

                return $html;
            }, $text);
        }

        // ==========================================
        // 2. Обработка тега {spoiler}
        // ==========================================
        if (strpos($text, '{spoiler') !== false) {
            $pattern = '/\{spoiler(?:\s+title=([^\}]+?))?(?:\s+opened=([0-9]))?\}(.*?)\{\/spoiler\}/is';
            $counter = 0;
            $text = preg_replace_callback($pattern, function($matches) use (&$counter) {
                $counter++;
                $title = isset($matches[1]) && !empty($matches[1]) ? trim($matches[1], ' "\'') : $this->params->get('default_title', 'Спойлер');
                $opened = isset($matches[2]) ? (int)$matches[2] : 0;
                $content = isset($matches[3]) ? $matches[3] : '';

                if ($this->params->get('lazy_load', 1)) {
                    $content = $this->makeImagesLazy($content);
                }

                $spoilerId = 'spoiler_' . $counter . '_' . uniqid();
                
                $buttonClass  = $this->params->get('button_class', 'btn-outline-secondary');
                $buttonSize   = $this->params->get('button_size', '');
                $contentClass = $this->params->get('content_class', 'bg-light');
                $borderClass  = $this->params->get('border_class', 'border-secondary');

                if ($buttonClass == '1') {
                    $buttonClass = trim($this->params->get('custom_button_style', ''));
                }
                if ($contentClass == '1') {
                    $contentClass = trim($this->params->get('custom_content_class', ''));
                }

				$buttonSizeClass = $buttonSize ? ' ' . $buttonSize : '';
				$collapseClass   = 'collapse' . ($opened ? ' show' : '');
				// ДОБАВЛЕНО: класс collapsed для закрытого состояния
				$buttonCollapsedClass = $opened ? '' : ' collapsed'; 

				$html = '<div class="spoiler card mb-3 ' . $borderClass . '">';
				$html .= '<div class="card-header p-0 border-bottom-0">';
				$html .= '<button class="spoiler-btn btn ' . $buttonClass . $buttonSizeClass . $buttonCollapsedClass . ' w-100 text-start d-flex align-items-center" type="button" data-bs-toggle="collapse" data-bs-target="#' . $spoilerId . '" aria-expanded="' . ($opened ? 'true' : 'false') . '" aria-controls="' . $spoilerId . '" style="border-radius:0;padding:0.5rem 1rem;min-height:44px;">';
                $html .= '<i class="spoiler-icon icon-angle-right me-2" aria-hidden="true"></i>';
                $html .= '<span>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</span>';
                $html .= '</button>';
                $html .= '</div>';
                $html .= '<div id="' . $spoilerId . '" class="spoiler-content ' . $collapseClass . '">';
                $html .= '<div class="card-body p-0 ' . $contentClass . '">';
                $html .= $content;
                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';

                return $html;
            }, $text);
        }

        $this->addAssets();
        return $text;
    }

    private function makeImagesLazy($content)
    {
        $content = preg_replace_callback('/<img([^>]*)src=["\']([^"\']+)["\']([^>]*)>/i', function($matches) {
            if (strpos($matches[0], 'data-src') !== false) {
                return $matches[0];
            }
            $attrs = trim($matches[1] . ' ' . $matches[3]);
            $src = $matches[2];

            if (!preg_match('/^https?:\/\//i', $src) && substr($src, 0, 1) !== '/') {
                $src = '/' . $src;
            }

            $placeholder = 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20100%20100%22%3E%3C%2Fsvg%3E';
            
            if (strpos($attrs, 'class=') !== false) {
                $attrs = preg_replace('/class=["\']([^"\']*)["\']/', 'class="$1 img-fluid"', $attrs);
            } else {
                $attrs .= ' class="img-fluid"';
            }

            return '<img ' . $attrs . ' src="' . $placeholder . '" data-src="' . htmlspecialchars($src) . '">';
        }, $content);
        return $content;
    }

    private function addAssets()
    {
        if (self::$assetsAdded) {
            return;
        }

        $doc = Factory::getDocument();

        if ($this->params->get('load_css', 1)) {

            $cssPath = Uri::root(true) . '/plugins/content/lazyspoiler/lazyspoiler.css';
            $doc->addStyleSheet($cssPath, ['version' => 'auto']);

            // Передаем динамическую переменную скорости анимации
            $speed = (int)$this->params->get('animation_speed', 300);
            $speedSec = $speed / 1000;
            $doc->addStyleDeclaration(':root { --ls-anim-speed: ' . $speedSec . 's; }');
        }

        $doc->addScriptDeclaration($this->getJS());
        self::$assetsAdded = true;
    }

	private function getJS()
	{
		$speed = (int)$this->params->get('animation_speed', 300);
		
		return '
		(function() {
			if (typeof window.lazySpoilerInitialized !== "undefined") {
				return;
			}
			window.lazySpoilerInitialized = true;

			function loadImagesInContainer(container) {
				container.querySelectorAll("img[data-src]").forEach(function(img) {
					var originalSrc = img.getAttribute("data-src");
					if (originalSrc) {
						img.src = originalSrc;
						img.removeAttribute("data-src");
					}
				});
			}

			// Функция инициализации обработчиков для всех details
			function initDetailsHandlers() {
				document.querySelectorAll("details").forEach(function(details) {
					// Защита от повторной инициализации
					if (details.dataset.lazyInit) return;
					details.dataset.lazyInit = "true";

					details.addEventListener("toggle", function() {
						if (details.open) loadImagesInContainer(details);
					});
					
					// Если спойлер уже открыт при загрузке страницы, грузим сразу
					if (details.open) loadImagesInContainer(details);
				});
			}

			// Слушаем события Bootstrap 5 collapse для старого спойлера
			document.addEventListener("show.bs.collapse", function(event) {
				var content = event.target;
				setTimeout(function() {
					loadImagesInContainer(content);
				}, ' . $speed . ');
			});

			// Проверяем готовность DOM
			if (document.readyState === "loading") {
				document.addEventListener("DOMContentLoaded", function() {
					document.querySelectorAll(".spoiler-content.show").forEach(loadImagesInContainer);
					initDetailsHandlers();
				});
			} else {
				// DOM уже готов
				document.querySelectorAll(".spoiler-content.show").forEach(loadImagesInContainer);
				initDetailsHandlers();
			}
		})();
		';
	}
}