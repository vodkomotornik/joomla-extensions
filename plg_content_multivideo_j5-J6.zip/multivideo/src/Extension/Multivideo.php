<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Vodkomotornik\Plugin\Content\Multivideo\Services\YouTubeService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\RutubeService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\VKService;

class Multivideo extends CMSPlugin
{
    protected $autoloadLanguage = true;

}