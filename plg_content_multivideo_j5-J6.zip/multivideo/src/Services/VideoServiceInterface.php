<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Services;

defined('_JEXEC') or die;

interface VideoServiceInterface
{
    public function matches($url);
    public function extractId($url);
    public function getEmbedCode($id, $width, $height, $useNocookie = true);
    public function getDisplayName();
    public function getKey();
}