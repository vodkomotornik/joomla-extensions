<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Services;

defined('_JEXEC') or die;

class VimeoService implements VideoServiceInterface
{
    public function matches($url)
    {
        return preg_match('/(vimeo\.com|player\.vimeo\.com)/i', $url);
    }
    
    public function extractId($url)
    {
        $patterns = [
            '/vimeo\.com\/(\d+)/i',
            '/player\.vimeo\.com\/video\/(\d+)/i',
            '/vimeo\.com\/channels\/[^\/]+\/(\d+)/i',
            '/vimeo\.com\/groups\/[^\/]+\/videos\/(\d+)/i',
            '/vimeo\.com\/album\/\d+\/video\/(\d+)/i'
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $url, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
    
    public function getEmbedCode($id, $width, $height, $useNocookie = true)
    {
        // Vimeo использует единый домен для всех
        $src = "https://player.vimeo.com/video/{$id}";
        
        // Дополнительные параметры Vimeo
        $params = [
            'autoplay' => 0,
            'loop' => 0,
            'autopause' => 1,
            'portrait' => 1,
            'title' => 1,
            'byline' => 1,
            'color' => '00adef',
            'dnt' => $useNocookie ? 1 : 0 // Do Not Track (аналог nocookie)
        ];
        
        $src .= '?' . http_build_query($params);
        
        return '<iframe 
                    width="' . htmlspecialchars($width) . '" 
                    height="' . htmlspecialchars($height) . '" 
                    src="' . $src . '" 
                    frameborder="0" 
                    allow="autoplay; fullscreen; picture-in-picture; clipboard-write" 
                    allowfullscreen 
                    loading="lazy"
                    sandbox="allow-scripts allow-same-origin allow-popups allow-presentation">
                </iframe>';
    }
    
    public function getDisplayName()
    {
        return 'Vimeo';
    }
    
    public function getKey()
    {
        return 'vimeo';
    }
}