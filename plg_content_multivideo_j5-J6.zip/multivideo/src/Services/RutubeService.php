<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Services;
defined('_JEXEC') or die;

class RutubeService implements VideoServiceInterface
{
    public function matches($url)
    {
        return preg_match('/rutube\.ru/i', $url);
    }

    public function extractId($url)
    {
        $patterns = [
            '/rutube\.ru\/video\/([a-f0-9]+)/i',
            '/rutube\.ru\/play\/embed\/([a-f0-9]+)/i',
            '/rutube\.ru\/shorts\/([a-f0-9]+)/i',  // ← Добавлено для Shorts
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $url, $matches)) {
                return $matches[1];  // Возвращаем только ID, слеш автоматически отбрасывается
            }
        }
        return null;
    }

    public function getEmbedCode($id, $width, $height, $useNocookie = true)
    {
        // ← Убрали слеш в конце, как в официальном embed-коде RuTube
        $src = "https://rutube.ru/play/embed/{$id}";
        
        return '<iframe width="' . $width . '" height="' . $height . '" '
            . 'src="' . $src . '" '
            . 'frameborder="0" '
            . 'allow="autoplay; encrypted-media; clipboard-write" '
            . 'allowfullscreen '
            . 'loading="lazy" '
            . 'sandbox="allow-scripts allow-same-origin allow-popups allow-presentation">'
            . '</iframe>';
    }

    public function getDisplayName()
    {
        return 'RuTube';
    }

    public function getKey()
    {
        return 'rutube';
    }
}