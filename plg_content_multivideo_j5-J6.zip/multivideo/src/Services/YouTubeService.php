<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Services;
defined('_JEXEC') or die;

class YouTubeService implements VideoServiceInterface
{
    public function matches($url)
    {
        return preg_match('/(youtube\.com|youtu\.be)/i', $url);
    }

    public function extractId($url)
    {
        $patterns = [
            '/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w\-]+)/i',
            '/youtube\.com\/embed\/([\w\-]+)/i',
            '/youtube\.com\/v\/([\w\-]+)/i',
            '/youtube\.com\/shorts\/([\w\-]+)/i',  // ← Добавлено для YouTube Shorts
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $url, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }

    public function getEmbedCode($id, $width, $height, $useNocookie = true)
    {
        $domain = $useNocookie ? 'www.youtube-nocookie.com' : 'www.youtube.com';
        $src = "https://{$domain}/embed/{$id}?rel=0&modestbranding=1&cc_load_policy=0&hl=ru";
        
        return '<iframe width="' . $width . '" height="' . $height . '" '
            . 'src="' . $src . '" '
            . 'frameborder="0" '
            . 'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen; picture-in-picture; screen-wake-lock" '
            . 'referrerpolicy="strict-origin-when-cross-origin" '
            . 'allowfullscreen '
            . 'loading="lazy" '
            . 'sandbox="allow-scripts allow-same-origin allow-popups allow-presentation">'
            . '</iframe>';
    }

    public function getDisplayName()
    {
        return 'YouTube';
    }

    public function getKey()
    {
        return 'youtube';
    }
}