<?php
namespace Vodkomotornik\Plugin\Content\Multivideo\Services;
defined('_JEXEC') or die;

class VKService implements VideoServiceInterface
{
    public function matches($url)
    {
        return preg_match('/(vk\.(com|ru)|vkvideo\.ru)/i', $url);
    }

    public function extractId($url)
    {
        // Поддерживаем как video, так и clip
        if (preg_match('/vk(?:video)?\.(?:com|ru)\/(?:video|clip)([\-_0-9]+)/i', $url, $matches)) {
            return $matches[1];
        }
        return null;
    }

    public function getEmbedCode($id, $width, $height, $useNocookie = true)
    {
        $parts = explode('_', $id);
        if (count($parts) == 2) {
            $oid = $parts[0];
            $vid = $parts[1];
        } else {
            $oid = $id;
            $vid = '';
        }

        // Определяем, клип это или видео (если oid начинается с минуса - это группа/клан)
        $isClip = (strpos($id, '-') === 0 || preg_match('/^-\d+_/',$id));
        
        // Для клипов используем clip_ext.php, для видео - video_ext.php
        $embedType = $isClip ? 'clip' : 'video';
        $src = "https://vkvideo.ru/{$embedType}_ext.php?oid={$oid}&id={$vid}&hd=3";
        
        return '<iframe width="' . $width . '" height="' . $height . '" src="' . $src . '" frameborder="0" allow="autoplay; encrypted-media; clipboard-write" allowfullscreen loading="lazy" sandbox="allow-scripts allow-same-origin allow-popups allow-presentation"></iframe>';
    }

    public function getDisplayName()
    {
        return 'ВК Видео';
    }

    public function getKey()
    {
        return 'vk';
    }
}