<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  
 *
 * 
 * 
 */
 
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Language\Text;

// Services
use Vodkomotornik\Plugin\Content\Multivideo\Services\YouTubeService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\RutubeService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\VKService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\VimeoService;
use Vodkomotornik\Plugin\Content\Multivideo\Services\VideoServiceInterface;

JLoader::registerNamespace('Vodkomotornik\Plugin\Content\Multivideo', __DIR__ . '/src', false, false, 'psr4');

class PlgContentMultivideo extends CMSPlugin
{
    protected $autoloadLanguage = true;
    
    /** Services **/
    private function getAvailableServices()
    {
        $services = [];
        $params = $this->params;
        
        if ($params->get('enable_youtube', 1)) {
            $services[] = new YouTubeService();
        }
        if ($params->get('enable_rutube', 1)) {
            $services[] = new RutubeService();
        }
        if ($params->get('enable_vk', 1)) {
            $services[] = new VKService();
        }
        if ($params->get('enable_vimeo', 1)) {  // ← Добавьте
        $services[] = new VimeoService();
		}
		
        return $services;
    }
    
    public function onContentPrepare($context, &$article, &$params, $page = 0)
    {
        // {video}
        if (strpos($article->text, '{video') === false) {
            return true;
        }
        
        // {video href="..."}
        $pattern = '/\{video\s+href="([^"]+)"\}/i';
        
        $article->text = preg_replace_callback($pattern, function($matches) {
            return $this->renderVideoTabs($matches[1]);
        }, $article->text);
        
        return true;
    }
    
    /*** renderVideoTabs ***/
private function renderVideoTabs($href)
{
    $urls = array_map('trim', explode('|', $href));
    $services = $this->getAvailableServices();
    $showErrors = $this->params->get('show_errors', 0);
    
    $videos = [];
    $unsupportedUrls = [];
    
    foreach ($urls as $url) {
        $found = false;
        foreach ($services as $service) {
            if ($service->matches($url)) {
                $id = $service->extractId($url);
                if ($id) {
                    $key = $service->getKey();
                    $videos[$key] = [
                        'service' => $service,
                        'id' => $id,
                        'url' => $url,
                        'name' => $service->getDisplayName()
                    ];
                    $found = true;
                }
                break;
            }
        }
        if (!$found && !empty($url)) {
            $unsupportedUrls[] = $url;
        }
    }

    // --- sort ---
    $sortValues = [];
    foreach ($videos as $key => $video) {
        $sortKey = 'sort_' . $key;
        $sortValues[$key] = (int)$this->params->get($sortKey, 5);
    }

    uasort($videos, function($a, $b) use ($sortValues) {
        $keyA = $a['service']->getKey();
        $keyB = $b['service']->getKey();
        return $sortValues[$keyA] <=> $sortValues[$keyB];
    });

    if (empty($videos)) {
        if ($showErrors && !empty($unsupportedUrls)) {
            
            $errorHtml = '<div class="alert alert-warning mv-error">
                            <strong>' . htmlspecialchars(Text::_('PLG_MULTIVIDEO_NO_VIDEOS')) . '</strong><br>
                            ' . htmlspecialchars(Text::_('PLG_MULTIVIDEO_SHOW_ERRORS_ERROR')) . '
                            <hr>
                            <small>⚠️ ' . htmlspecialchars(Text::_('PLG_MULTIVIDEO_UNSUPPORTED_SERVICE')) . ':<br>
                            ' . htmlspecialchars(implode('<br>', $unsupportedUrls)) . '</small>
                          </div>';
            return $errorHtml;
        }
        return '<!-- MultiVideo: ' . Text::_('PLG_MULTIVIDEO_NO_SERVICES') . ' -->';
    }
    
    $warningHtml = '';
    if ($showErrors && !empty($unsupportedUrls)) {
        $warningHtml = '<div class="alert alert-danger" role="alert">
                            <strong>⚠️ ' . htmlspecialchars(Text::_('PLG_MULTIVIDEO_UNSUPPORTED_SERVICE')) . ':</strong><br>
                            <small>' . htmlspecialchars(implode('<br>', $unsupportedUrls)) . '</small>
                        </div>';
    }
    
    $blockId = 'mv-' . uniqid();
    
    // HTML
    $html = $warningHtml . $this->renderTabsHtml($videos, $blockId);
    
    // CSS и JS
    $this->addAssets($blockId);
    
    return $html;
}
    
    /*** HTML ***/
    private function renderTabsHtml($videos, $blockId)
    {
        $useNocookie = $this->params->get('use_nocookie', 1);
        $width = preg_match('/^[\d%a-z]+$/i', $this->params->get('video_width', '720')) 
         ? $this->params->get('video_width', '720') 
         : '720';
        $height = preg_match('/^[\d%a-z]+$/i', $this->params->get('video_height', '405')) 
         ? $this->params->get('video_height', '405') 
         : '720';

        $html = '<div class="mv-container" id="' . $blockId . '">';
        $html .= '<div class="mv-tabs">';
        
        $isFirst = true;
        foreach ($videos as $key => $video) {
            $activeClass = $isFirst ? 'active' : '';
            $html .= '<button class="mv-tab-btn ' . $activeClass . '" data-service="' . $key . '">' . htmlspecialchars($video['name']) . '</button>';
            $isFirst = false;
        }
        
        $html .= '</div>';
        $html .= '<div class="mv-content text-center">';
        
        $isFirst = true;
        foreach ($videos as $key => $video) {
            $activeClass = $isFirst ? 'active' : '';
            $embedCode = $video['service']->getEmbedCode($video['id'], $width, $height, $useNocookie);
            
            $html .= '<div class="mv-pane ' . $activeClass . '" data-service="' . $key . '">';
            $html .= $embedCode;
            $html .= '</div>';
            
            $isFirst = false;
        }
        
        $html .= '</div>';
        $html .= '</div>';
        
        return $html;
    }
    
    /*** CSS и JavaScript ***/
    private function addAssets($blockId)
    {
        $doc = Factory::getApplication()->getDocument();
        
        // CSS
        $css = '
        .mv-container {
            margin: 20px 0;
            font-family: inherit;
        }
        .mv-content.text-center {
            background-color: black;
        }
        .mv-tabs {
            display: flex;
            gap: 5px;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 1px;
            flex-wrap: wrap;
        }
        .mv-tab-btn {
            padding: 8px 16px;
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            color: #6c757d;
            border-radius: 4px 4px 0 0;
            transition: all 0.2s ease;
        }
        .mv-tab-btn:hover {
            color: #007bff;
            background: rgba(0,123,255,0.1);
        }
        .mv-tab-btn.active {background-color:#fff;
            color: #007bff;
            border-bottom: 2px solid #007bff;
			border-left: 1px solid #ebecef;
			border-right: 1px solid #ebecef;
			border-top: 1px solid #ebecef;
        }
        .mv-content .mv-pane {
            display: none;
        }
        .mv-content .mv-pane.active {
            display: block;
        }
        ';
        $doc->addStyleDeclaration($css);
        
        // JavaScript
        $js = '
        document.addEventListener("DOMContentLoaded", function() {
            var container = document.getElementById("' . $blockId . '");
            if (!container) return;
            
            var buttons = container.querySelectorAll(".mv-tab-btn");
            var panes = container.querySelectorAll(".mv-pane");
            
            buttons.forEach(function(btn) {
                btn.addEventListener("click", function() {
                    var service = this.getAttribute("data-service");
                    
                    buttons.forEach(function(b) { b.classList.remove("active"); });
                    panes.forEach(function(p) { p.classList.remove("active"); });
                    
                    this.classList.add("active");
                    var activePane = container.querySelector(".mv-pane[data-service=\"" + service + "\"]");
                    if (activePane) activePane.classList.add("active");
                });
            });
        });
        ';
        
        $footer = $this->params->get('js_in_footer', 1);
        if ($footer) {
            $doc->addScriptDeclaration($js, 'text/javascript', ['type' => 'text/javascript', 'defer' => true]);
        } else {
            $doc->addScriptDeclaration($js);
        }
    }
}